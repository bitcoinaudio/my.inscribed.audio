# @bitcoinaudio-org/signer

_Last updated: 2026-07-25_

Shared human-authorization signer for every BitcoinAudio frontend. One
capability-oriented signing surface with adapters, so the five frontends stop
reimplementing extension-dependent `WalletContext` logic and a sixth can't
inherit it. Built for [production-workspace#30](https://github.com/bitcoinaudio-org/production-workspace/issues/30).

Beatfeed remains the sole account/role authority and the only capability
issuer. This package only **produces bound signatures / connections**; it never
mints, custodies, or forwards reusable credentials.

## Entry points

Subpath exports keep the unisat-only frontends off `nostr-tools`:

| Import | Provides | Peer deps |
| --- | --- | --- |
| `@bitcoinaudio-org/signer/nostr` | NIP-07 + NIP-46 (nostrconnect:// / bunker:// / NIP-05) adapters, `configureSigner` | `nostr-tools` |
| `@bitcoinaudio-org/signer/wallet` | BIP-322 wallet signing (UniSat / Xverse), `resolveSigningMethod` | none |
| `@bitcoinaudio-org/signer/react` | Nostr-only `WalletLogin`, action-scoped `PaymentWalletButton`, and provider hooks | `react`, `nostr-tools` |
| `@bitcoinaudio-org/signer` | root re-export of nostr + wallet | `nostr-tools` |

`nostr-tools` and `react` are **optional** peer dependencies — a frontend that
only imports `/wallet` never installs them.

## Usage

```js
// Set per-frontend signer identity once at startup.
import { configureSigner } from '@bitcoinaudio-org/signer/nostr'
configureSigner({ name: 'Beatfeed', url: 'https://beatfeed.xyz' })

// Mobile NIP-46 (no browser extension needed):
import { createNip46Connection, installRemoteNostrProvider } from '@bitcoinaudio-org/signer/nostr'
const session = createNip46Connection({ onAuthUrl: (url) => showQr(url) })
render(session.uri)                 // QR / deep link for the signer app
const signer = await session.connect()
installRemoteNostrProvider(signer)  // now window.nostr signs remotely; reuse existing login

// Desktop NIP-07 fallback:
import { createNip07Signer } from '@bitcoinaudio-org/signer/nostr'
const signer = createNip07Signer()  // wraps window.nostr

// BIP-322 wallet signature:
import { signWalletMessage } from '@bitcoinaudio-org/signer/wallet'
const sig = await signWalletMessage(boundMessage, { provider: 'unisat', address })
```

### Identity and payment UI

`WalletLogin` intentionally offers only Nostr identity. It shows NIP-07 on
desktop and NIP-46 on mobile; it never shows an unavailable device-specific
signer. Bitcoin wallets are exposed separately and only at a paid action:

```jsx
import { PaymentWalletButton, WalletLogin } from '@bitcoinaudio-org/signer/react'

<WalletLogin />
<PaymentWalletButton
  label="Pay with"
  onReady={({ provider, address }) => startCheckout({ provider, address })}
/>
```

Connecting or disconnecting a payment wallet does not authenticate the user,
replace their Nostr roles, or log them out.

## Provenance

Extracted verbatim from Beatfeed's merged mobile-authorization work
(`beatfeed.xyz` PR #19, `web/src/utils/nostrSigner.js`) plus the reusable
signing helpers from `WalletContext.jsx`. The hardcoded Beatfeed signer metadata
is now configurable via `configureSigner()`.

## Tests

```bash
npm install
npm test          # node --test across src/**/*.test.js
```

## Roadmap (production-workspace#30)

- **Phase 2** — adopt in all five frontends; delete the per-frontend copies;
  finalize the `/react` hook against a real consumer.
- **Phase 3** — add a `/webauthn` adapter (passkey account auth + action-bound
  step-up) fitting the same interface.
